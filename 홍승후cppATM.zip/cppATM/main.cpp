#include<iostream>
#include "ATM.h"
int main()
{
	ATM a;
	a.menu();
	return 0;
}